# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['atk_hcloud_upload']

package_data = \
{'': ['*']}

install_requires = \
['typer>=0.7.0,<0.8.0']

entry_points = \
{'console_scripts': ['atk-hcloud-download = atk_hcloud_upload.download:main',
                     'atk-hcloud-upload = atk_hcloud_upload.sync:main']}

setup_kwargs = {
    'name': 'atk-hcloud-upload',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Nitesh',
    'author_email': 'nitesh@aganitha.ai',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
